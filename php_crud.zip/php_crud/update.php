<!-- DATABASE CONNECTION FILE INCLUDE -->
<?php include 'connection.php';
$id = $_GET['id'];

$select="SELECT * FROM users WHERE id='$id'";
$select_q=mysqli_query($conn,$select);
$fetch=mysqli_fetch_array($select_q);
?>

<!-- HTML FORM CODE -->
<html>
<head>
    <title>Index</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <!-- BOOTSTRAP LINK -->
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" 
    integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <!-- CSS LINK -->
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px;">
            <div class="card-body p-5">
            <h3 align="center" class="mb-2">Update Details</h3>
              <form action="" method="POST" enctype="multipart/form-data">

                <div class="form-outline mb-4">
                  <input type="text" id="name" name="name" placeholder="Enter Name" 
                   value="<?php echo $fetch['name']?>"  class="form-control form-control-lg" required />
                </div>

                <div class="form-outline mb-4">
                  <input type="number" name="contact" id="contact" placeholder="Enter Contact No" value="<?php echo $fetch['contact']?>"
                  class="form-control form-control-lg" maxlength="10" onKeyPress="if(this.value.length==10) return false;" required/>
                </div>

                <div class="form-outline mb-4">
                  <input type="email" id="email" name="email" placeholder="Enter Email Id" value="<?php echo $fetch['email']?>"
                  class="form-control form-control-lg" required />
                </div>

                <div class="form-outline mb-4">
                   <textarea id="address" name="address" class="form-control form-control-lg" rows="3" 
                   placeholder="Enter Your Address"><?php echo $fetch['address']?></textarea>
                </div>

                <div class="form-outline mb-4">
                  <input type="number" id="pincode " name="pincode" placeholder="Enter Area Pincode" value="<?php echo $fetch['pincode']?>"
                  class="form-control form-control-lg" maxlength="6" onKeyPress="if(this.value.length==6) return false;" required />
                </div>

                <b><div class="row">
                  <div class="form-outline mb-4 ml-3">
                      <label>Gender:</label>
                  </div></b>
                  <div class="form-outline mb-4 ml-3">
                      <input type="radio" name="gender" id="male" value="male"
                      <?php
                      if(strtolower($fetch['gender']) == "male")
                      {
                          echo "checked";
                      }
                      ?>
                      ><label>Male</label>
                  </div>
                  <div class="form-outline mb-4 ml-3">
                      <input type="radio" name="gender" id="female" value="female"
                      <?php
                      if(strtolower($fetch['gender']) == "female")
                      {
                          echo "checked";
                      }
                      ?>
                      ><label>Female</label>
                  </div>
                  <div class="form-outline mb-4 ml-3">
                      <input type="radio" name="gender" id="other" value="other"
                      <?php
                      if(strtolower($fetch['gender']) == "other")
                      {
                          echo "checked";
                      }
                      ?>
                      ><label>Other</label>
                  </div>
                </div>

                <b><div class="form-outline mb-4">
                <label>Select City:</label>
	                <select id="city" name="city" class="select ml-3">
                    <option value="Ahmedabad"
                    <?php
                    if($fetch['city'] == "Ahmedabad")
                    {
                      echo "selected";
                    }
                    ?>
                    >
                    Ahmedabad</option>
                    <option value="Gujarat"
                    <?php
                    if($fetch['city'] == "Gujarat")
                    {
                      echo "selected";
                    }
                    ?>
                    >
                    Gujarat</option>
                    <option value="Surat"
                    <?php
                    if($fetch['city'] == "Surat")
                    {
                      echo "selected";
                    }
                    ?>
                    >
                    Surat</option>
	                </select>
                </div></b>

                <div class="form-outline mb-4">
                  <input type="password" id="password" name="password" placeholder="Enter Password" 
                      value="<?php echo $fetch['password']?>" class="form-control form-control-lg" />
                </div>

                <div class="form-outline mb-4">
                  <input type="file" id="image" name="image" class="form-control form-control-lg"/>
                  <img src="images/<?php echo $fetch['image']?>" width="100px" height="70px" style="margin-top: 10px;">
                </div>

                <div class="form-outline mb-4">
                  <textarea class="form-control form-control-lg" name="message" 
                  id="message" placeholder="Enter Message"><?php echo $fetch['message']?></textarea>
                </div>
             
                <div class="d-flex justify-content-center">
                  <button type="submit" name="update_btn" class="btn btn-dark btn-lg btn-block">Update Data
                  </button>
                </div>

                <!-- PHP CODE -->

                <?php
                  if (isset($_POST['update_btn'])) 
                  {
                    $name = $_POST['name'];
                    $contact = $_POST['contact'];
                    $email = $_POST['email'];
                    $address = $_POST['address'];
                    $pincode = $_POST['pincode'];
                    $gender = $_POST['gender'];
                    $city = $_POST['city'];
                    $password = $_POST['password'];
                    $message = $_POST['message'];
                    $image = $_FILES['image']['name'];
                    $tmp_name = $_FILES['image']['tmp_name'];
                    $destination = "images/" . $image;

                    // Check if a new password is provided
                    if (!empty($_POST['password'])) 
                    {
                      $password = $_POST['password'];
                      $passwordmd5 = md5($password); 
                    } 
                    else 
                    {
                      $passwordmd5 = $fetch['password']; 
                    }

                    $allowed_extension = array('gif', 'png', 'jpg');
                    $filename = $_FILES['image']['name'];
                    $file_extension = pathinfo($filename, PATHINFO_EXTENSION);

                    // Check if the email already exists in the database except for the current record
                    $check_query = "SELECT * FROM users WHERE email = '$email' AND id != '$id'";
                    $check_result = mysqli_query($conn, $check_query);

                    if (mysqli_num_rows($check_result) > 0) 
                    {
                      echo "<p>Email address already exists in the database.</p>";
                    } 
                    else 
                    {
                      // Check if a new image is uploaded
                      if (!empty($image)) 
                      {
                        if (!in_array($file_extension, $allowed_extension)) 
                        {
                          echo "<p>You are allowed with png and gif</p>";
                        } 
                        else 
                        {
                          move_uploaded_file($tmp_name, $destination);
                          $update = "UPDATE users SET name='$name',password='$passwordmd5',contact='$contact',email='$email',gender='$gender',message='$message',image='$image' WHERE id='$id'";
                          $query = mysqli_query($conn, $update);

                          move_uploaded_file($_FILES['image']['name'], "upload/" . $_FILES['image']['name']);
                          echo "<p>Data Update</p>";
                          ?>
                            <script>
                              window.location = 'http://localhost/small_projects/php_crud/display.php';
                            </script>
                          <?php
                        }
                      } 
                      else 
                      {
                        // If no new image is uploaded, update the other fields without changing the image
                        $update = "UPDATE users SET name='$name',contact='$contact',email='$email',address='$address',pincode='$pincode',gender='$gender',city='$city',message='$message',password='$passwordmd5' WHERE id='$id'";
                        $query = mysqli_query($conn, $update);
                        echo "<p>Data Update</p>";
                        ?>
                          <script>
                            window.location = 'http://localhost/small_projects/php_crud/display.php';
                          </script>
                        <?php
                      }
                    }
                  }
                  ?>

                <!-- PHP CODE END -->

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- password validation -->
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      document.querySelector('form').addEventListener('submit', function (e) {
        var password = document.getElementById('password').value;
        // Check if a new password is provided (not empty)
        if (password !== "") 
        {
          if (!isPasswordValid(password)) 
          {
              e.preventDefault(); // Prevent form submission
              alert('Password must be at least 6 characters long and contain a combination of alphabets and numbers.');
          }
        }
      });

      function isPasswordValid(password) {
        // Password must be at least 6 characters long
        if (password.length < 6) 
        {
          return false;
        }
        // Password must contain at least one alphabet
        var alphabetRegex = /[a-zA-Z]/;
        if (!alphabetRegex.test(password)) 
        {
          return false;
        }
        // Password must contain at least one number
        var numberRegex = /[0-9]/;
        if (!numberRegex.test(password)) 
        {
          return false;
        }
        return true;
      }
    });
  </script>
</body>
</html>    
