<!-- DATABASE CONNECTION FILE INCLUDE -->
<?php include 'connection.php';?>

<!-- HTML FORM CODE -->
<html>
<head>
    <title>Display Data</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <!-- BOOTSTRAP LINK -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" 
    integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <!-- CSS LINK -->
    <link rel="stylesheet" href="style.css"/>
</head>
<body style="background-color: white !important;">
	<table border="1px" cellpadding="10" cellspacing="0px" align="center" id="table">
		<tr>
			<th>Id</th>
			<th>Name</th>
			<th>Contact</th>
			<th>Email</th>
			<th>Pincode</th>
			<th>Gender</th>
			<th>City</th>
			<th>Image</th>
			<th colspan="2">Actions <button class="btn btn-danger btn-sm float-right"><a href="index.php" id="link">Insert</a></button></th>
		</tr>
		<?php
			$select="SELECT * FROM users";
			$select_q=mysqli_query($conn,$select);
			$data=mysqli_num_rows($select_q);
			if($data)
			{
				while ($row=mysqli_fetch_array($select_q)) 
				{
					?>
					<tr>
						<td><?php echo $row['id'];?></td>
						<td><?php echo $row['name'];?></td>
						<td><?php echo $row['contact'];?></td>
						<td><?php echo $row['email'];?></td>
						<td><?php echo $row['pincode'];?></td>
						<td><?php echo $row['gender'];?></td>
						<td><?php echo $row['city'];?></td>
						<td><img src="images/<?php echo $row['image']?>" width="100px" height="70px"></td>
						<td><button class="btn btn-danger btn-block"><a href="update.php?id=<?php echo $row['id']?>" id="link">Update</a></button></td>
						<td> <button class="btn btn-danger btn-block"><a onclick="return confirm('Are u sure u want to delete data?')" href="delete.php?id=<?php echo $row['id']?>" id="link">Delete</a></button></td>
					</tr>
					<?php
				}
			}
			else
			{
				echo "<p>Sorry No Record Found</P>";
			}
		?>
	</table>
</body>
</html>