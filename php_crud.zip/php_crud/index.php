<!-- DATABASE CONNECTION FILE INCLUDE -->
<?php include 'connection.php';?>
<!-- HTML FORM CODE -->
<html>
<head>
    <title>Index</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <!-- BOOTSTRAP LINK -->
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" 
    integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <!-- CSS LINK -->
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px;">
            <div class="card-body p-5">
              <h3 align="center" class="mb-2">Fill Details</h3>
              <form action="" method="POST" enctype="multipart/form-data">

                <div class="form-outline mb-4">
                  <input type="text" id="name" name="name" placeholder="Enter Name" 
                  class="form-control form-control-lg"  required />
                </div>

                <div class="form-outline mb-4">
                  <input type="number" name="contact" id="contact" placeholder="Enter Contact No" 
                  class="form-control form-control-lg" maxlength="10" onKeyPress="if(this.value.length==10) return false;" required/>
                </div>

                <div class="form-outline mb-4">
                  <input type="email" id="email" name="email" placeholder="Enter Email Id" 
                  class="form-control form-control-lg" required />
                </div>

                <div class="form-outline mb-4">
                   <textarea id="address" name="address" class="form-control form-control-lg" rows="3" 
                   placeholder="Enter Your Address"></textarea>
                </div>

                <div class="form-outline mb-4">
                  <input type="number" id="pincode " name="pincode" placeholder="Enter Area Pincode" 
                  class="form-control form-control-lg" maxlength="6" onKeyPress="if(this.value.length==6) return false;" required />
                </div>

                <b><div class="row">
	               <div class="form-outline mb-4 ml-3">
	                    <label>Gender:</label>
	               </div></b>
	               <div class="form-outline mb-4 ml-3">
	                 <input type="radio" name="gender" id="male" value="Male"><label>Male</label>
	               </div>
                   <div class="form-outline mb-4 ml-3">
                      <input type="radio" name="gender" id="female" value="Female"><label>Female</label>
                    </div>
                    <div class="form-outline mb-4 ml-3">
                      <input type="radio" name="gender" id="other" value="Other"><label>Other</label>
                    </div>
                </div>

                <b><div class="form-outline mb-4">
                <label>Select City:</label>
	                <select id="city" name="city" class="select ml-3">
                      <option value="">Select Option</option>
	                    <option value="Ahmedabad">Ahmedabad</option>
	                    <option value="Gujarat">Gujarat</option>
	                    <option value="Surat">Surat</option>
	                </select>
                </div></b>

                <div class="form-outline mb-4">
                  <input type="password" id="password" name="password" placeholder="Enter Password ex: tEst@123" 
                  class="form-control form-control-lg" required />
                </div>

                <div class="form-outline mb-4">
                  <input type="password" id="cpassword" name="cpassword" placeholder="Enter Confirm Password" 
                  class="form-control form-control-lg" required />
                </div>

                <div class="form-outline mb-4">
                  <input type="file" id="image" accept="image/" name="image" 
                  class="form-control form-control-lg" required />
                </div>

                <div class="form-outline mb-4">
                  <textarea class="form-control form-control-lg" name="message" 
                  id="message" placeholder="Enter Message"></textarea>
                </div>

                <div class="d-flex justify-content-center">
                  <button type="submit" name="save_data" class="btn btn-dark btn-lg btn-block">Save Data
                  </button>
                </div>

                <!-- PHP CODE -->
                <?php
                  if (isset($_POST['save_data'])) 
                  {
                    $name = $_POST['name'];
                    $contact = $_POST['contact'];
                    $email = $_POST['email'];
                    $address = $_POST['address'];
                    $pincode = $_POST['pincode'];
                    $gender = $_POST['gender'];
                    $city = $_POST['city'];
                    $password = $_POST['password'];
                    $cpassword = $_POST['cpassword'];
                    $message = $_POST['message'];
                    $image = $_FILES['image']['name'];
                    $tmp_name = $_FILES['image']['tmp_name'];
                    $destination = "images/" . $image;
                    move_uploaded_file($tmp_name, $destination);

                    $allowed_extension = array('gif', 'png', 'jpg');
                    $filename = $_FILES['image']['name'];
                    $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
                    if (!in_array($file_extension, $allowed_extension)) 
                    {
                      echo "<p>You are allowed with png and gif</P>";
                    } 
                    else 
                    {
                      // Check if the email already exists in the database
                      $query = "SELECT * FROM users WHERE email = '$email'";
                      $result = mysqli_query($conn, $query);

                      if (mysqli_num_rows($result) > 0) 
                      {
                        echo "<p>Email address already exists in the database.</p>";
                      } 
                      else 
                      {
                        $exists = false;
                        if (($password == $cpassword) && $exists == false) 
                        {
                          $passwordmd5 = md5($password);
                          $insert_query = "INSERT INTO users (name,contact,email,address,pincode,gender,city,password,message,image) 
                                  VALUES ('$name','$contact','$email','$address','$pincode','$gender','$city','$passwordmd5','$message','$image')";

                          $result = mysqli_query($conn, $insert_query);
                          if ($result) 
                          {
                            move_uploaded_file($_FILES['image']['tmp_name'], "upload/" . $_FILES['image']['name']);
                            echo "<p>Data Stored</P>";
                            ?>
                              <script>
                                window.location = 'http://localhost/small_projects/php_crud/display.php';
                              </script>
                            <?php
                            
                          } 
                          else 
                          {
                            echo "<p>Data Not Stored</P>";
                          }
                        } 
                        else 
                        {
                          echo "<p>Password Does Not match</p>";
                        }
                      }
                    }
                  }
                ?>
                <!-- PHP CODE END -->

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- password validation -->
  <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelector('form').addEventListener('submit', function (e) {
          var password = document.getElementById('password').value;
          if (!isPasswordValid(password)) 
          {
            e.preventDefault(); // Prevent form submission
            alert('Password must be at least 6 characters long and contain special characters, alphabets, and numbers.');
          }
      });
      function isPasswordValid(password) 
      {
        // Password must be at least 6 characters long
        if (password.length < 6) 
        {
          return false;
        }
        // Password must contain at least one special character
        var specialCharRegex = /[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]/;
        if (!specialCharRegex.test(password)) 
        {
          return false;
        }
        // Password must contain at least one alphabet
        var alphabetRegex = /[a-zA-Z]/;
        if (!alphabetRegex.test(password)) 
        {
          return false;
        }

        // Password must contain at least one number
        var numberRegex = /[0-9]/;
        if (!numberRegex.test(password)) 
        {
          return false;
        }
        return true;
      }
    });
  </script>

</body>
</html>    