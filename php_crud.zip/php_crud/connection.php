<?php
$servername="localhost";
$username="root";
$password="";
$dbname="crud_form";

// create connection
$conn=mysqli_connect($servername,$username,$password,$dbname);

// chek connection
if($conn)
{
	echo "";
}
else
{
	echo "Not Connected Pl. try again";
}
?>